# Fluxograma - Ciência de Dados-EMAp

Creating an interactive fluxogram for the new Data Science course of EMAp-FGV. 
