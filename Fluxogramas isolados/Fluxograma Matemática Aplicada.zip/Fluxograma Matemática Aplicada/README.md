# Fluxograma - Matemática Aplicada-EMAp

Creating a new interactive fluxogram for the Applied Mathematics course of Emap-FGV. 
